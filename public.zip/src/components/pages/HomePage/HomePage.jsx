import axios from "axios";

import { useEffect } from "react";
import { useState } from "react";
import scss from "./home.module.scss";
import { useNavigate } from "react-router-dom";

const url =
  "https://api.elchocrud.pro/api/v1/c0e897a7d3ab43aa192e995ac4e054c4/user_regitration";
const HomePage = () => {
  const [user, setuser] = useState([]);
  const navigate = useNavigate();

  const getRequest = async () => {
    const response = await axios.get(url);
    const responseData = response.data;
    setuser(responseData);
  };

  useEffect(() => {
    getRequest();
  }, []);

  const exitFunc = () => {
    localStorage.removeItem("isAuth");
    navigate("/login");
  };

  return (
    <div className="container">
      <div className={scss.content}>
        <div className={scss.card}>
          {user.map((item, index) => (
            <div className={scss.user_card} key={index}>
              <h2>{item.name}</h2>
            </div>
          ))}
        </div>
        <button onClick={exitFunc}>Exit</button>
      </div>
    </div>
  );
};

export default HomePage;
