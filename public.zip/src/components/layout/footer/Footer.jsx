const Footer = () => {
  return <footer className="container">footer</footer>;
};

export default Footer;
